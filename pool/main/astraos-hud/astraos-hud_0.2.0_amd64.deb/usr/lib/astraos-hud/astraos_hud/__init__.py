"""AstraOS HUD — full-screen session dashboard.

Package layout note
-------------------
The application is installed as a plain importable package under
``/usr/lib/astraos-hud`` and launched by a POSIX shell shim in ``/usr/bin`` that
puts that directory on PYTHONPATH and runs ``python3 -m astraos_hud`` - the same
``__main__.py`` entry point the source tree is run with during development:

    ASTRAOS_HUD_LIB="/usr/lib/astraos-hud"
    PYTHONPATH="${ASTRAOS_HUD_LIB}${PYTHONPATH:+:${PYTHONPATH}}"
    exec python3 -m astraos_hud "$@"

Nothing here imports GTK at module scope. ``import astraos_hud.systemdata`` must
keep working on a build host with no PyGObject installed at all — the data layer
is exercised by the static tests and by the packaging build, and a package that
can only be imported on a machine with GTK is a package that cannot be checked.

Modules
-------
``systemdata``  every /proc, /sys and socket reading. Standard library only.
``widgets``     the custom Cairo drawing widgets (meters, graph, globe, table).
``layout``      the six-region grid, panel chrome and the single sampling tick.
``main``        argument parsing, single-instance guard, Gtk.main().
"""

from __future__ import annotations

from typing import Any

__all__ = ["__version__", "APP_NAME", "main"]

#: Kept in step with the repository VERSION file and with config/distribution.env, and
#: checked by tests/static/test_config.py so that it cannot silently fall behind: it read
#: 0.1.0 while the release was 0.2.0.
__version__ = "0.2.0"

APP_NAME = "AstraOS HUD"


def main(argv: Any = None) -> int:
    """Run the HUD. Imported lazily so the package stays GTK-free on import.

    ``from .main import main`` rather than ``from . import main``: this function is
    named ``main`` and is bound on the package, so ``from . import main`` would find
    the function itself (the package attribute shadows the submodule) and the call
    below would raise AttributeError. The submodule has to be named explicitly.
    """
    from .main import main as _run

    return _run(argv)
